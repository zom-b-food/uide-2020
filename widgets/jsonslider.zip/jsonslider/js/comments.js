var comments = [
  {"name":"Garfield","comment":"The most active thing about me is my imagination.","timestamp":69379200000},
  {"name":"Daffy Duck","comment":"Maybe if I stare at this paper long enough people will think I can read.","timestamp":1007683200000},
  {"name":"Bugs Bunny","comment":"Eh, what's up doc? Got any carrots?","timestamp":583113600000},
  {"name":"Olaf","comment":"Some people are worth melting for.","timestamp":172281600000},
  {"name":"Snow White","comment":"You're never too old to be young","timestamp":882489600000},
  {"name":"Wreck-It Ralph","comment":"There's no one I'd rather be than me.","timestamp":678326400000},
  {"name":"Mickey Mouse","comment":"To laugh at yourself is to love yourself.","timestamp":1215993600000"}
];
<?php wp_nav_menu(array('theme_location'=>'footer')); ?>
